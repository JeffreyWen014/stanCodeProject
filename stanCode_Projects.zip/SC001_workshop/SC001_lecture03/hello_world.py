"""
File: hello_world.py
Name: JeffreyWen
-----------------------------------
This program prints 'hello, world!'
on Console and shows the basic 
Python syntax
"""


def main():
	print('Hello, World!', end="")
	print('That Time I Got Reincarnate as a Slime',end="")
	print('WOW!', end="")


# ----- DO NOT MODIFY CODE BELOW THIS LINE ----- #
if __name__ == '__main__':
	main()
