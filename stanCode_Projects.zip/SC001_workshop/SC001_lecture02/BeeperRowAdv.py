"""
File: BeeperRowAdv.py
Name: JeffreyWen
------------------------------
This program makes Karel fill up
Street 1 with some beepers already
existed
(This should be world insensitive)
"""

from karel.stanfordkarel import *


def main():
    """
    Karel will fill the first Street in any world
    """
    while front_is_clear():
        if not on_beeper():  # Check if there is a beeper underfoot
            put_beeper()
        move()
    if not on_beeper():
        put_beeper()


# ----- DO NOT MODIFY CODE BELOW THIS LINE ----- #
if __name__ == '__main__':
    execute_karel_task(main)